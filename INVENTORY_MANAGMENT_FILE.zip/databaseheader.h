#ifndef DATABASEHEADER_H
#define DATABASEHEADER_H

#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlDriver>
#include <QtSql/QSqlError>
#include <QDebug>
#include <QtSql/QSqlTableModel>
#include <QFile>
#include <QMessageBox>
#include <QSqlQuery>


#endif // DATABASEHEADER_H
